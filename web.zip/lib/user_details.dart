import 'package:flutter/material.dart';
import 'package:leaderboard/responsive.dart';

class UserDetails extends StatefulWidget {
  const UserDetails({Key? key}) : super(key: key);

  @override
  State<UserDetails> createState() => _UserDetailsState();
}

class _UserDetailsState extends State<UserDetails> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        height: MediaQuery.of(context).size.height,
        width: MediaQuery.of(context).size.width,
        color: Color(0xFFC3675A),
        child: Padding(
          padding: EdgeInsets.only(
            left: responsiveWidth(8, context),
            right: responsiveHeight(8, context),
            top: responsiveHeight(58, context),
            bottom: responsiveHeight(19, context),
          ),
          child: Container(
            height: responsiveHeight(735, context),
            width: responsiveWidth(296, context),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(40),
            ),
            child: Column(
              children: [
                SizedBox(
                  height: responsiveHeight(30, context),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
